﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using StockMicroservice.Business.Stock.Dto;
using StockMicroservice.Controllers;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace XUnitTestEStockMarket.StockMicroserviceTest
{
    public abstract class BaseToStockControllerTest
    {
        protected readonly StockController ControllerUnderTest;
        protected readonly StockResultDto stockResultDto;
        protected BaseToStockControllerTest()
        {
            stockResultDto = new StockResultDto()
            {
            };

            var logger = new Mock<ILogger<StockController>>();
            ControllerUnderTest = new StockController(logger.Object);
        }
    }

    public class CompanyTest : BaseToStockControllerTest
    {
        [Fact]
        public async void GetStockDetalis()
        {
            var result = await ControllerUnderTest.GetStockDetalis("TGA");
            var viewresult = Assert.IsType<ActionResult<StockResultDto>>(result);
            Assert.Equal(stockResultDto.StockDetails[0].CompanyCode, viewresult.Value.StockDetails[0].CompanyCode);
        }
    }
}
