﻿using CompanyMicroservice.Business.Company.Dto;
using CompanyMicroservice.Controllers;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Abstractions;

namespace XUnitTestEStockMarket.CompanyMicroServiceTest
{
    
    public abstract class BaseToCompanyControllerTest
    {
        protected readonly CompanyController ControllerUnderTest;
        protected readonly CompanyResultDto companyResultDto;
        protected BaseToCompanyControllerTest()
        {
            companyResultDto = new CompanyResultDto()
            {

                CompanyCode = "TGA",
                CompanyName = "ANANTH FIN",
                CompanyCEO = "Ananth G",
                CompanyTurnover = 100000001,
                CompanyWebsite = "www.ananthfin.com",
                StockExchange = 2
            };

            var logger = new Mock<ILogger<CompanyController>>();
            ControllerUnderTest = new CompanyController(logger.Object);
        }
    }

    public class CompanyTest : BaseToCompanyControllerTest
    {
        [Fact]
        public async void GetCompanyDetalis()
        {
            var result = await ControllerUnderTest.GetCompanyDetalis("TGA");
            var viewresult = Assert.IsType<ActionResult<CompanyResultDto>>(result);
            Assert.Equal(companyResultDto.CompanyName, viewresult.Value.CompanyName);
        }
    }
}
