﻿using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StockMicroservice.Presistence.Collections
{
    public class Stocks
    {
        public ObjectId Id { get; set; }
        public DateTime CreatedDate = DateTime.UtcNow;
        public string CompanyCode { get; set; }
        public decimal StockPrice { get; set; }
        public DateTime StockDateTime = DateTime.UtcNow;
    }
}
