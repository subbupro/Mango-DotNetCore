﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using StockMicroservice.Business.Stock.Commands;
using StockMicroservice.Business.Stock.Dto;
using StockMicroservice.Business.Stock.Queries;

namespace StockMicroservice.Controllers
{
    [Route("api/v{version:apiVersion}/market/stock")]
    [ApiController]
    public class StockController : BaseController
    {
        private readonly ILogger<StockController> _logger;

        public StockController(ILogger<StockController> logger)
        {
            _logger = logger;
        }

        [HttpPost]
        [Route("add")]
        [ResponseCache(NoStore = true, Duration = 0)]
        public async Task<ActionResult<int>> SaveStock(StockDto stockDto)
        {
            try
            {
                var stock = await Mediator.Send(new SaveStockQuery(stockDto));
                return Ok(stock);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                return BadRequest(ex.ToString());
            }
        }

        [HttpGet("get/{companyCode}/{startDate}/{endDate}")]
        [ResponseCache(NoStore = true, Duration = 0)]
        public async Task<IActionResult> GetsStockByCompanyId(string companyCode, DateTime startDate, DateTime endDate)
        {
            try
            {
                var stockData = await Mediator.Send(new GetStockListQuery(companyCode, startDate, endDate));
                return Ok(stockData);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                return BadRequest(ex.ToString());
            }
        }

        [HttpGet("info/{companyCode}")]
        [ResponseCache(NoStore = true, Duration = 0)]
        public async Task<IActionResult> GetStockDetalis(string companyCode)
        {
            try
            {
                var stockDetails = await Mediator.Send(new GetLatestStockByCompanyIdQuery(companyCode));
                return Ok(stockDetails);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                return BadRequest(ex.ToString());
            }
        }

        [HttpDelete("delete/{companyCode}")]
        [ResponseCache(NoStore = true, Duration = 0)]
        public async Task<IActionResult> DeleteStockByCompanyId(string companyCode)
        {
            try
            {
                var stock = await Mediator.Send(new DeleteStockByCompanyIdQuery(companyCode));
                return Ok(stock);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                return BadRequest(ex.ToString());
            }
        }
    }
}
