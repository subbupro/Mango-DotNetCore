﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StockMicroservice.Common
{
    public class Constants
    {
        public const string MESSAGE_DATA_SAVED_SUCCESSFULLY = "Data Saved Successfully";
        public const string MESSAGE_DATA_SAVE_FAILED = "Data Save Failed";
        public const string MESSAGE_DATA_DELETED_SUCCESSFULLY = "Data Deleted Successfully";
        public const string MESSAGE_DATA_DELETION_FAILED = "Data Deletion Failed";
        public const string MESSAGE_DATA_RETRIEVED_SUCCESSFULLY = "Data Retrieved Successfully";

        #region Stock
        public const string MESSAGE_STOCKPRICE_VALIDATION = "StockPrice must be greater than zero.";
        #endregion
    }
}
