﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StockMicroservice.Business.Stock.Dto
{
    public class StockResultDto
    {
        public List<StockDetailsDto> StockDetails { get; set; }
        public StockPriceDifferenceDto StockPriceDifference { get; set; }
    }
}
