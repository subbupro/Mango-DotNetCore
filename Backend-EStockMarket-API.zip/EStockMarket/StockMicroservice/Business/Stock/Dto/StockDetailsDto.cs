﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StockMicroservice.Business.Stock.Dto
{
    public class StockDetailsDto
    {
        public string CompanyCode { get; set; }
        public decimal StockPrice { get; set; }
        public DateTime StockDateTime { get; set; }
    }
}
