﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StockMicroservice.Business.Stock.Dto
{
    public class StockPriceDifferenceDto
    {
        public decimal Maximum { get; set; }
        public decimal Minimum { get; set; }
        public decimal Average { get; set; }
    }
}
