﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace StockMicroservice.Business.Stock.Dto
{
    public class StockDto
    {
        [Required]
        public string CompanyCode { get; set; }
        [Required]
        public decimal StockPrice { get; set; }
    }
}
