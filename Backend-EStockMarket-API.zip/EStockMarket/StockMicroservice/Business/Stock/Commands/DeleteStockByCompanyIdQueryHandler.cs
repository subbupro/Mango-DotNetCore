﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using StockMicroservice.Business.Response;
using StockMicroservice.Common;
using StockMicroservice.Presistence;
using StockMicroservice.Presistence.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace StockMicroservice.Business.Stock.Commands
{
    public class DeleteStockByCompanyIdQueryHandler : IRequestHandler<DeleteStockByCompanyIdQuery, Response.ResponseResult<bool>>
    {
        private readonly IOptions<DatabaseSettings> _databaseSettings;
        private readonly ILogger<DeleteStockByCompanyIdQueryHandler> _logger;
        private readonly IMongoCollection<Stocks> _stock;
        public DeleteStockByCompanyIdQueryHandler(IMongoClient client, ILogger<DeleteStockByCompanyIdQueryHandler> logger, IOptions<DatabaseSettings> databaseSettings)
        {
            _databaseSettings = databaseSettings;
            var database = client.GetDatabase(_databaseSettings.Value.DatabaseName);
            var collection = database.GetCollection<Stocks>(nameof(Stocks));
            _stock = collection;
            _logger = logger;
        }

        public async Task<ResponseResult<bool>> Handle(DeleteStockByCompanyIdQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var filter = Builders<Stocks>.Filter.Eq(c => c.CompanyCode, request.CompanyCode);
                var result = await _stock.DeleteManyAsync(filter);
                if (result.DeletedCount > 0)
                {

                    return new Response.ResponseResult<bool>
                    {
                        Result = true,
                        Messages = new List<string> { Constants.MESSAGE_DATA_DELETED_SUCCESSFULLY },
                        success = true,
                        StatusCode = System.Net.HttpStatusCode.OK,
                        Errors = { }
                    };
                }
                else
                {
                    return new Response.ResponseResult<bool>
                    {
                        Result = false,
                        Messages = new List<string> { Constants.MESSAGE_DATA_DELETION_FAILED },
                        success = false,
                        StatusCode = System.Net.HttpStatusCode.OK,
                        Errors = { }
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                throw ex;
            }
        }
    }
}
