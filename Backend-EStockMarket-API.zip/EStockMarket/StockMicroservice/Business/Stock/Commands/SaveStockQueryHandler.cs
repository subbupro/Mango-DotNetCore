﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using StockMicroservice.Common;
using StockMicroservice.Presistence;
using StockMicroservice.Presistence.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace StockMicroservice.Business.Stock.Commands
{
    public class SaveStockQueryHandler : IRequestHandler<SaveStockQuery, Response.ResponseResult<int>>
    {
        private readonly IOptions<DatabaseSettings> _databaseSettings;
        private readonly ILogger<SaveStockQueryHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IMongoCollection<Stocks> _stock;

        public SaveStockQueryHandler(IMongoClient client, ILogger<SaveStockQueryHandler> logger, IMapper mapper, IOptions<DatabaseSettings> databaseSettings)
        {
            _databaseSettings = databaseSettings;
            var database = client.GetDatabase(_databaseSettings.Value.DatabaseName);
            var collection = database.GetCollection<Stocks>(nameof(Stocks));
            _stock = collection;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<Response.ResponseResult<int>> Handle(SaveStockQuery request, CancellationToken cancellationToken)
        {
            try
            {
                if(request.Inputs.StockPrice <= 0)
                {
                    return new Response.ResponseResult<int>
                    {
                        Result = 0,
                        Messages = new List<string> { Constants.MESSAGE_STOCKPRICE_VALIDATION },
                        success = false,
                        StatusCode = System.Net.HttpStatusCode.OK,
                        Errors = { }
                    };
                }
                await _stock.InsertOneAsync(_mapper.Map<Stocks>(request.Inputs));
                return new Response.ResponseResult<int>
                {
                    Result = 1,
                    Messages = new List<string> { Constants.MESSAGE_DATA_SAVED_SUCCESSFULLY },
                    success = true,
                    StatusCode = System.Net.HttpStatusCode.OK,
                    Errors = { }
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                throw ex;
            }
        }
    }
}
