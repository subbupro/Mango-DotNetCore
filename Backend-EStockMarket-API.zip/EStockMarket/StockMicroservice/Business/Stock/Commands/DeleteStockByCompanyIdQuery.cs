﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StockMicroservice.Business.Stock.Commands
{
    public class DeleteStockByCompanyIdQuery : IRequest<Response.ResponseResult<bool>>
    {
        public string CompanyCode { get; }
        public DeleteStockByCompanyIdQuery(string companyCode)
        {
            CompanyCode = companyCode;
        }
    }
}
