﻿using MediatR;
using StockMicroservice.Business.Stock.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StockMicroservice.Business.Stock.Commands
{
    public class SaveStockQuery : IRequest<Response.ResponseResult<int>>
    {
        public StockDto Inputs { get; }
        public SaveStockQuery(StockDto inputs)
        {
            Inputs = inputs;
        }
    }
}
