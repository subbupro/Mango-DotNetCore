﻿using MediatR;
using StockMicroservice.Business.Stock.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StockMicroservice.Business.Stock.Queries
{
    public class GetLatestStockByCompanyIdQuery : IRequest<Response.ResponseResult<StockDetailsDto>>
    {
        public string CompanyCode { get; }
        public GetLatestStockByCompanyIdQuery(string companyCode)
        {
            CompanyCode = companyCode;
        }
    }
}
