﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using StockMicroservice.Business.Response;
using StockMicroservice.Business.Stock.Dto;
using StockMicroservice.Common;
using StockMicroservice.Presistence;
using StockMicroservice.Presistence.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace StockMicroservice.Business.Stock.Queries
{
    public class GetStockListQueryHandler : IRequestHandler<GetStockListQuery, Response.ResponseResult<StockResultDto>>
    {
        private readonly IOptions<DatabaseSettings> _databaseSettings;
        private readonly ILogger<GetStockListQueryHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IMongoCollection<Stocks> _stock;

        public GetStockListQueryHandler(IMongoClient client, ILogger<GetStockListQueryHandler> logger, IMapper mapper, IOptions<DatabaseSettings> databaseSettings)
        {
            _databaseSettings = databaseSettings;
            var database = client.GetDatabase(_databaseSettings.Value.DatabaseName);
            var collection = database.GetCollection<Stocks>(nameof(Stocks));
            _stock = collection;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<Response.ResponseResult<StockResultDto>> Handle(GetStockListQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var stockListData =  _mapper.Map<List<StockDetailsDto>>(await _stock.Find(e => e.CompanyCode.Equals(request.CompanyCode) && e.StockDateTime >= request.StartDate && e.StockDateTime <= request.EndDate).ToListAsync());
                var stockResult = new StockResultDto();
                var stockPriceDifference = new StockPriceDifferenceDto();
                stockResult.StockDetails = stockListData;
                stockPriceDifference.Maximum = stockListData.Max(e => e.StockPrice);
                stockPriceDifference.Minimum = stockListData.Min(e => e.StockPrice);
                stockPriceDifference.Average = stockListData.Average(e => e.StockPrice);
                stockResult.StockPriceDifference = stockPriceDifference;
                return new Response.ResponseResult<StockResultDto>
                {
                    Result = stockResult,
                    Messages = new List<string> { Constants.MESSAGE_DATA_RETRIEVED_SUCCESSFULLY },
                    success = true,
                    StatusCode = System.Net.HttpStatusCode.OK,
                    Errors = { }
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                throw ex;
            }
        }
    }
}
