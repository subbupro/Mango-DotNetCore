﻿using AutoMapper;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using StockMicroservice.Business.Response;
using StockMicroservice.Business.Stock.Dto;
using StockMicroservice.Common;
using StockMicroservice.Presistence;
using StockMicroservice.Presistence.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace StockMicroservice.Business.Stock.Queries
{
    public class GetLatestStockByCompanyIdQueryHandler : IRequestHandler<GetLatestStockByCompanyIdQuery, Response.ResponseResult<StockDetailsDto>>
    {
        private readonly IOptions<DatabaseSettings> _databaseSettings;
        private readonly ILogger<GetLatestStockByCompanyIdQueryHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IMongoCollection<Stocks> _stock;

        public GetLatestStockByCompanyIdQueryHandler(IMongoClient client, ILogger<GetLatestStockByCompanyIdQueryHandler> logger, IMapper mapper, IOptions<DatabaseSettings> databaseSettings)
        {
            _databaseSettings = databaseSettings;
            var database = client.GetDatabase(_databaseSettings.Value.DatabaseName);
            var collection = database.GetCollection<Stocks>(nameof(Stocks));
            _stock = collection;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task<ResponseResult<StockDetailsDto>> Handle(GetLatestStockByCompanyIdQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var companyData = _mapper.Map<StockDetailsDto>(await _stock.Find(e => e.CompanyCode.Equals(request.CompanyCode)).SortByDescending(e=> e.StockDateTime).FirstOrDefaultAsync());
                return new Response.ResponseResult<StockDetailsDto>
                {
                    Result = companyData,
                    Messages = new List<string> { Constants.MESSAGE_DATA_RETRIEVED_SUCCESSFULLY },
                    success = true,
                    StatusCode = System.Net.HttpStatusCode.OK,
                    Errors = { }
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                throw ex;
            }
        }
    }
}
