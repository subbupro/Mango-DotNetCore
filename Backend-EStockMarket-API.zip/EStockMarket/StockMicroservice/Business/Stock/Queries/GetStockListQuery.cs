﻿using MediatR;
using StockMicroservice.Business.Stock.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StockMicroservice.Business.Stock.Queries
{
    public class GetStockListQuery : IRequest<Response.ResponseResult<StockResultDto>>
    {
        public string CompanyCode { get; }
        public DateTime StartDate { get; }
        public DateTime EndDate { get; }
        public GetStockListQuery(string companyCode, DateTime startDate, DateTime endDate)
        {
            CompanyCode = companyCode;
            StartDate = startDate;
            EndDate = endDate;
        }
    }
}
