﻿using AutoMapper;
using StockMicroservice.Business.Stock.Dto;
using StockMicroservice.Presistence.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StockMicroservice.Business.Infrastructure
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            this.CreateMap<Stocks, StockDto>().ReverseMap();
            this.CreateMap<Stocks, StockDetailsDto>().ReverseMap();
        }
    }
}
