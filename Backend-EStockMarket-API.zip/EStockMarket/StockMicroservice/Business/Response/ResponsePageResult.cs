﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StockMicroservice.Business.Response
{
    public class ResponsePageResult<TModel> : Response
    {
        public TModel Result { get; set; }
        public int TotalRecords { get; set; }
    }
}
