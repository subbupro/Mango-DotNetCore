﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyMicroservice.Common
{
    public class Constants
    {
        public const string MESSAGE_DATA_SAVED_SUCCESSFULLY = "Data Saved Successfully";
        public const string MESSAGE_DATA_SAVE_FAILED = "Data Save Failed";
        public const string MESSAGE_DATA_DELETED_SUCCESSFULLY = "Data Deleted Successfully";
        public const string MESSAGE_DATA_DELETION_FAILED = "Data Deletion Failed";
        public const string MESSAGE_DATA_RETRIEVED_SUCCESSFULLY = "Data Retrieved Successfully";

        #region Company
        public const decimal COMPANYTURNOVER = 100000000;
        public const string MESSAGE_COMPANYTURNOVER_VALIDATION = "CompanyTurnover must be greater than 10 Cr.";
        public const string MESSAGE_STOCKEXCHANGE_VALIDATION = "StockExchange vlaue must be 1(BSE) or 2(NSE).";
        public const string MESSAGE_COMPANYCODE_VALIDATION = "CompanyCode already exists in application.";
        #endregion
    }
}
