﻿using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace CompanyMicroservice.Business.Company.Dto
{
    public class CompanyDto
    {
        [Required]
        public string CompanyCode { get; set; }
        [Required]
        public string CompanyName { get; set; }
        [Required]
        public string CompanyCEO { get; set; }
        [Required]
        public decimal CompanyTurnover { get; set; }
        [Required]
        public string CompanyWebsite { get; set; }
        [Required]
        public int StockExchange { get; set; }
    }
}
