﻿using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace CompanyMicroservice.Business.Company.Dto
{
    public class CompanyResultDto
    {
        public string CompanyCode { get; set; }
        public string CompanyName { get; set; }
        public string CompanyCEO { get; set; }
        public decimal CompanyTurnover { get; set; }
        public string CompanyWebsite { get; set; }
        public int StockExchange { get; set; }
        public decimal LatestStockPrice { get; set; }
    }
}
