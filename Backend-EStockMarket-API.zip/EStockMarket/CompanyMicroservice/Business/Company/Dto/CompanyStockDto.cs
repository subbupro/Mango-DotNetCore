﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyMicroservice.Business.Company.Dto
{
    public class CompanyStockDto
    {
        public string CompanyCode { get; set; }
        public decimal StockPrice { get; set; }
        public DateTime StockDateTime { get; set; }
    }
}
