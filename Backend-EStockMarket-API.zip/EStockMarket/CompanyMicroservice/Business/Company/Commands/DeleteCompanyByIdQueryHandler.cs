﻿using AutoMapper;
using CompanyMicroservice.Common;
using CompanyMicroservice.Presistence;
using CompanyMicroservice.Presistence.Collections;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace CompanyMicroservice.Business.Company.Commands
{
    public class DeleteCompanyByIdQueryHandler : IRequestHandler<DeleteCompanyByIdQuery, Response.ResponseResult<bool>>
    {
        private readonly IOptions<DatabaseSettings> _databaseSettings;
        private readonly ILogger<DeleteCompanyByIdQueryHandler> _logger;
        private readonly IMongoCollection<Companies> _company;
        public DeleteCompanyByIdQueryHandler(IMongoClient client, ILogger<DeleteCompanyByIdQueryHandler> logger, IOptions<DatabaseSettings> databaseSettings)
        {
            _databaseSettings = databaseSettings;
            var database = client.GetDatabase(_databaseSettings.Value.DatabaseName);
            var collection = database.GetCollection<Companies>(nameof(Companies));
            _company = collection;
            _logger = logger;
        }
        public async Task<Response.ResponseResult<bool>> Handle(DeleteCompanyByIdQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var filter = Builders<Companies>.Filter.Eq(c => c.CompanyCode, request.CompanyCode);
                var result = await _company.DeleteOneAsync(filter);
                if(result.DeletedCount == 1)
                {
                    var URL = _databaseSettings.Value.StockUrl;
                    var userResource = $"delete/{ request.CompanyCode}";
                    using (var httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(URL);
                        var response = await httpClient.DeleteAsync(userResource);
                        await response.Content.ReadAsStringAsync();
                    }

                    return new Response.ResponseResult<bool>
                    {
                        Result = true,
                        Messages = new List<string> { Constants.MESSAGE_DATA_DELETED_SUCCESSFULLY },
                        success = true,
                        StatusCode = System.Net.HttpStatusCode.OK,
                        Errors = { }
                    };
                }
                else
                {
                    return new Response.ResponseResult<bool>
                    {
                        Result = false,
                        Messages = new List<string> { Constants.MESSAGE_DATA_DELETION_FAILED },
                        success = false,
                        StatusCode = System.Net.HttpStatusCode.OK,
                        Errors = { }
                    };
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                throw ex;
            }
        }
    }
}
