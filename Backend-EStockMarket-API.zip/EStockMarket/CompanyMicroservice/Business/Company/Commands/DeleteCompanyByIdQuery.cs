﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyMicroservice.Business.Company.Commands
{
    public class DeleteCompanyByIdQuery : IRequest<Response.ResponseResult<bool>>
    {
        public string CompanyCode { get; }
        public DeleteCompanyByIdQuery(string companyCode)
        {
            CompanyCode = companyCode;
        }
    }
}
