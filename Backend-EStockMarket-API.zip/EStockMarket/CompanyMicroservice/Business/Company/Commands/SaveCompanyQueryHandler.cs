﻿using CompanyMicroservice.Business.Company.Dto;
using CompanyMicroservice.Presistence;
using MediatR;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using CompanyMicroservice.Presistence.Collections;
using AutoMapper;
using CompanyMicroservice.Common;
using Microsoft.Extensions.Options;

namespace CompanyMicroservice.Business.Company.Commands
{
    public class SaveCompanyQueryHandler : IRequestHandler<SaveCompanyQuery, Response.ResponseResult<int>>
    {
        private readonly IOptions<DatabaseSettings> _databaseSettings;
        private readonly ILogger<SaveCompanyQueryHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IMongoCollection<Companies> _company;
        public SaveCompanyQueryHandler(IMongoClient client, ILogger<SaveCompanyQueryHandler> logger, IMapper mapper, IOptions<DatabaseSettings> databaseSettings)
        {
            _databaseSettings = databaseSettings;
             var database = client.GetDatabase(_databaseSettings.Value.DatabaseName);
            var collection = database.GetCollection<Companies>(nameof(Companies));
            _company = collection;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<Response.ResponseResult<int>> Handle(SaveCompanyQuery request, CancellationToken cancellationToken)
        {
            try
            {
                if(request.Inputs.CompanyTurnover <= Constants.COMPANYTURNOVER)
                {
                    return new Response.ResponseResult<int>
                    {
                        Result = 0,
                        Messages = new List<string> { Constants.MESSAGE_COMPANYTURNOVER_VALIDATION },
                        success = false,
                        StatusCode = System.Net.HttpStatusCode.OK,
                        Errors = { }
                    };
                }
                if (request.Inputs.StockExchange == 0)
                {
                    return new Response.ResponseResult<int>
                    {
                        Result = 0,
                        Messages = new List<string> { Constants.MESSAGE_STOCKEXCHANGE_VALIDATION },
                        success = false,
                        StatusCode = System.Net.HttpStatusCode.OK,
                        Errors = { }
                    };
                }
                var company = await _company.Find(e => e.CompanyCode.Equals(request.Inputs.CompanyCode)).FirstOrDefaultAsync(); 
                if(company == null)
                {
                    await _company.InsertOneAsync(_mapper.Map<Companies>(request.Inputs));
                    return new Response.ResponseResult<int>
                    {
                        Result = 1,
                        Messages = new List<string> { Constants.MESSAGE_DATA_SAVED_SUCCESSFULLY },
                        success = true,
                        StatusCode = System.Net.HttpStatusCode.OK,
                        Errors = { }
                    };
                }
                else
                {
                    return new Response.ResponseResult<int>
                    {
                        Result = 0,
                        Messages = new List<string> { Constants.MESSAGE_COMPANYCODE_VALIDATION },
                        success = false,
                        StatusCode = System.Net.HttpStatusCode.OK,
                        Errors = { }
                    };
                }
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                throw ex;
            }
        }
    }
}
