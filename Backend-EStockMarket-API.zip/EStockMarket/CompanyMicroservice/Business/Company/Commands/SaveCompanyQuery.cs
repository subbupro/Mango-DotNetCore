﻿using CompanyMicroservice.Business.Company.Dto;
using MediatR;
using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyMicroservice.Business.Company.Commands
{
    public class SaveCompanyQuery : IRequest<Response.ResponseResult<int>>
    {
        public CompanyDto Inputs { get; }
        public SaveCompanyQuery(CompanyDto inputs)
        {
            Inputs = inputs;
        }
    }
}
