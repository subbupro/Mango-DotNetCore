﻿using CompanyMicroservice.Business.Company.Dto;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyMicroservice.Business.Company.Queries
{
    public class GetCompanyListQuery : IRequest<Response.ResponsePageResult<IEnumerable<CompanyResultDto>>>
    {
        public GetCompanyListQuery()
        {

        }
    }
}
