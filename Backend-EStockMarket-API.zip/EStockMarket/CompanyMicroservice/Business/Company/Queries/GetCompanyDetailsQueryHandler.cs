﻿using AutoMapper;
using CompanyMicroservice.Business.Company.Dto;
using CompanyMicroservice.Business.Response;
using CompanyMicroservice.Common;
using CompanyMicroservice.Presistence;
using CompanyMicroservice.Presistence.Collections;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace CompanyMicroservice.Business.Company.Queries
{
    public class GetCompanyDetailsQueryHandler : IRequestHandler<GetCompanyDetailsQuery, Response.ResponseResult<CompanyResultDto>>
    {
        private readonly IOptions<DatabaseSettings> _databaseSettings;
        private readonly ILogger<GetCompanyDetailsQueryHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IMongoCollection<Companies> _company;
        public GetCompanyDetailsQueryHandler(IMongoClient client, ILogger<GetCompanyDetailsQueryHandler> logger, IMapper mapper, IOptions<DatabaseSettings> databaseSettings)
        {
            _databaseSettings = databaseSettings;
            var database = client.GetDatabase(_databaseSettings.Value.DatabaseName);
            var collection = database.GetCollection<Companies>(nameof(Companies));
            _company = collection;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<Response.ResponseResult<CompanyResultDto>> Handle(GetCompanyDetailsQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var companyData =  _mapper.Map<CompanyResultDto>(await _company.Find(e => e.CompanyCode.Equals(request.CompanyCode)).FirstOrDefaultAsync());
                var URL = _databaseSettings.Value.StockUrl;
                var userResource = $"info/{ request.CompanyCode}";
                using (var httpClient = new HttpClient())
                {
                    httpClient.BaseAddress = new Uri(URL);
                    var response = await httpClient.GetAsync(userResource);
                    var details = JsonConvert.DeserializeObject<ResponseResult<CompanyStockDto>>(response.Content.ReadAsStringAsync().Result);
                    companyData.LatestStockPrice = details.Result != null ? details.Result.StockPrice : 0;
                }
                return new Response.ResponseResult<CompanyResultDto>
                {
                    Result = companyData,
                    Messages = new List<string> { Constants.MESSAGE_DATA_RETRIEVED_SUCCESSFULLY },
                    success = true,
                    StatusCode = System.Net.HttpStatusCode.OK,
                    Errors = { }
                };
            }
            catch(Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                throw ex;
            }
        }
    }
}
