﻿using CompanyMicroservice.Business.Company.Dto;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyMicroservice.Business.Company.Queries
{
    public class GetCompanyDetailsQuery : IRequest<Response.ResponseResult<CompanyResultDto>>
    {
        public string CompanyCode { get; }
        public GetCompanyDetailsQuery(string companyCode)
        {
            CompanyCode = companyCode;
        }
    }
}
