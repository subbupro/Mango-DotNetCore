﻿using AutoMapper;
using CompanyMicroservice.Business.Company.Dto;
using CompanyMicroservice.Business.Response;
using CompanyMicroservice.Common;
using CompanyMicroservice.Presistence;
using CompanyMicroservice.Presistence.Collections;
using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace CompanyMicroservice.Business.Company.Queries
{
    public class GetCompanyListQueryHandler : IRequestHandler<GetCompanyListQuery, Response.ResponsePageResult<IEnumerable<CompanyResultDto>>>
    {
        private readonly IOptions<DatabaseSettings> _databaseSettings;
        private readonly ILogger<GetCompanyListQueryHandler> _logger;
        private readonly IMapper _mapper;
        private readonly IMongoCollection<Companies> _company;
        public GetCompanyListQueryHandler(IMongoClient client, ILogger<GetCompanyListQueryHandler> logger, IMapper mapper,IOptions<DatabaseSettings> databaseSettings)
        {
            _databaseSettings = databaseSettings;
            var database = client.GetDatabase(_databaseSettings.Value.DatabaseName);
            var collection = database.GetCollection<Companies>(nameof(Companies));
            _company = collection;
            _logger = logger;
            _mapper = mapper;
        }
        public async Task<Response.ResponsePageResult<IEnumerable<CompanyResultDto>>> Handle(GetCompanyListQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var companyListData =  _mapper.Map<IEnumerable<CompanyResultDto>>( await _company.Find(_ => true).ToListAsync());
                var companyList = new ResponsePageResult<IEnumerable<CompanyResultDto>>();
                foreach(var company in companyListData)
                {
                    var URL = _databaseSettings.Value.StockUrl;
                    var userResource = $"info/{ company.CompanyCode}";
                    using (var httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(URL);
                        var response = await httpClient.GetAsync(userResource);
                        var details = JsonConvert.DeserializeObject<ResponseResult<CompanyStockDto>>(response.Content.ReadAsStringAsync().Result);
                        company.LatestStockPrice = details.Result != null ? details.Result.StockPrice : 0;
                    }
                }
                companyList.Result = companyListData;
                companyList.Messages = new List<string> { Constants.MESSAGE_DATA_RETRIEVED_SUCCESSFULLY };
                companyList.success = true;
                companyList.StatusCode = System.Net.HttpStatusCode.OK;
                companyList.Errors = null;
                companyList.TotalRecords = companyListData.Count();
                return companyList;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                 throw ex;
            }
        }
    }
}
