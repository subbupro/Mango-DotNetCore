﻿using AutoMapper;
using CompanyMicroservice.Business.Company.Dto;
using CompanyMicroservice.Presistence.Collections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace CompanyMicroservice.Business.Infrastructure
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            this.CreateMap<Companies, CompanyDto>().ReverseMap();
            this.CreateMap<Companies, CompanyResultDto>().ReverseMap();
        }
    }


}
