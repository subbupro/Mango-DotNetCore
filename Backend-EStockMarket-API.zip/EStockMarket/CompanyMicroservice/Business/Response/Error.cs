﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CompanyMicroservice.Business.Response
{
    public class Error
    {
        public string ErrorCode { get; set; }
        public string Message { get; set; }
    }
}
