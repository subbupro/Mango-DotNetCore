﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace CompanyMicroservice.Business.Response
{
    public class Response
    {
        public IList<Error> Errors { get; set; }
        public IList<string> Messages { get; set; }
        public bool success { get; set; }
        public HttpStatusCode StatusCode { get; set; }
    }
}
