﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CompanyMicroservice.Business.Company.Commands;
using CompanyMicroservice.Business.Company.Dto;
using CompanyMicroservice.Business.Company.Queries;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace CompanyMicroservice.Controllers
{
    [Route("api/v{version:apiVersion}/market/company")]
    [ApiController]
    public class CompanyController : BaseController
    {
        private readonly ILogger<CompanyController> _logger;

        public CompanyController(ILogger<CompanyController> logger)
        {
            _logger = logger;
        }

        [HttpPost]
        [Route("register")]
        [ResponseCache(NoStore = true, Duration = 0)]
        public async Task<ActionResult<int>> SaveCompany(CompanyDto companyDto)
        {
            try
            {
                var company = await Mediator.Send(new SaveCompanyQuery(companyDto));
                return Ok(company);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                return BadRequest(ex.ToString());
            }
        }

        [HttpGet("info/{companyCode}")]
        [ResponseCache(NoStore = true, Duration = 0)]
        public async Task<IActionResult> GetCompanyDetalis(string companyCode)
        {
            try
            {
                var companyDetails = await Mediator.Send(new GetCompanyDetailsQuery(companyCode));
                return Ok(companyDetails);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                return BadRequest(ex.ToString());
            }
        }

        [HttpGet("getall")]
        [ResponseCache(NoStore = true, Duration = 0)]
        public async Task<IActionResult> GetCompanyList()
        {
            try
            {
                var companyList = await Mediator.Send(new GetCompanyListQuery());
                return Ok(companyList);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                return BadRequest(ex.ToString());
            }
        }

        [HttpDelete("delete/{companyCode}")]
        [ResponseCache(NoStore = true, Duration = 0)]
        public async Task<IActionResult> DeleteCompanyById(string companyCode)
        {
            try
            {
                var company = await Mediator.Send(new DeleteCompanyByIdQuery(companyCode));
                return Ok(company);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex.StackTrace);
                return BadRequest(ex.ToString());
            }
        }
    }
}
